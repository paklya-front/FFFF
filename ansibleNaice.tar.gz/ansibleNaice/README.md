# Об Ansible

[Можно почитать тут](https://gitlab.eltex.loc/ems-group/softwlc/tools/ansible)

# Установка Ansible
[Установка Ansible]
(https://docs.ansible.com/ansible/latest/installation_guide/installation_distros.html)

(https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html)


# Запуск Ansible

Для подключения по SSH Ansible использует ключи (а не пароли), потому ключи нужно предварительно забросить на ту машину, которой вы собираетесь управлять.

Сделать это можно вот так. Нужно будет ввести свой пароль.
```
$ ssh-copy-id -i ~/.ssh/eltex.pub mikhail_gaydamaka@10.25.96.80
...
Now try logging into the machine, with:   "ssh 'mikhail_gaydamaka@10.25.96.80'"
and check to make sure that only the key(s) you wanted were added.
```
После этого команда `ssh mikhail_gaydamaka@10.25.96.80` будет проходить без запроса пароля.

Создать ключ можно так
```
ssh-keygen -t rsa -b 4096 -C "mikhail.gaydamaka@eltex.loc"
```

Если вы используете Asbru Connection Manager, настройке в соединении Authentication, Private key и укажите путь к `/.ssh/eltex`.

На сервере должен присутствовать sudo, а пользователь, от имени которого будет выполняться установка, должен быть в группе sudo.

Так же необходимо создать файл с настройками ansible.cfg в корневой директории ansible. Пример можно посмотреть в ansible.cfg.template.

В большинстве случаев изменится только поле remote_user.

Адрес машины (сервера или виртуалки) указывает в отдельном файле [hosts.yml](hosts.yml). Все хосты разделены на группы. При запуске скрипта (например, common-naice-services.yml), в нём нужно заполнить поле hosts, указать там имя отдельного сервера (например, lab516) или группы (common), что будет означать запуск скрипта сразу на всех адресах, перечисленным в группе.


# Установка NAICE

[Инструкция по установке NAICE (v0.5)](https://docs.eltex-co.ru/pages/viewpage.action?pageId=488734820)

> **Кратко**
>
> Для разворачивания системы NAICE необходимо запустить несколько ansible-плейбуков на один целевой хост в следующей последовательности: 
>
>- `common-naice-databases.yml`  \*
>- `common-naice-services.yml`
>- `common-freeradius.yml`  \*\*
>
> \* Если БД необходимо установить в виде сервиса. Для запуска БД в docker запуск этого плейбука не требуется.  
> \*\* Если RADIUS необходимо установить в виде сервиса. Для запуска RADIUS в docker запуск этого плейбука не требуется.
>
> Перед запуском плейбуков не забудьте указать параметры доступа к целевому хосту в [hosts.yml](hosts.yml) и изменить необходимые параметры развертывания в переменных [group_vars/all.yml](group_vars/all.yml).


# Сборник рецептов Ansible

Все скрипты тестируются на Ubuntu 22.04.2 LTS, Jammy

## Проверка перед стартом

Взял отсюда [docs.ansible.com](https://docs.ansible.com/ansible/latest/getting_started/index.html)

* `ansible --version`
* `ansible-playbook --version` - Check out version installed
* `ansible all --list-hosts` - Verify the hosts in your inventory
* `ansible all -m ping` - Ping the managed nodes

## Информация о состоянии системы

Этот Playbook просто выводит время в системе, статус сервисов и т.д.

Может запускаться как проверочный, потому что ничего не модифицирует. Однако работать без ошибок он будет, когда всё окружение уже установлено. Плюс скрипт содержит избыточный набор модулей, не все из которых уже официально входят в решение NAICE.

```
$ ansible-playbook common-info.yml
```

Для отображения статуса сервисов используется [service_facts модуль](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/service_facts_module.html)

## NTP, timezone

[This module](https://docs.ansible.com/ansible/latest/collections/community/general/timezone_module.html) 
is part of the community.general collection (version 6.5.0).

Установка зависимостей
```
ansible-galaxy collection install community.general
```
Установить таймзону, NTP сервер, распечатать дату и время:
```
ansible-playbook --ask-become-pass common-ntp.yml
```

## FreeRadius
Playbook common-freeradius.yml, повторяет настройку окружения из https://intdocs.eltex.loc/pages/viewpage.action?pageId=110671330

> **Важно**
>
> Плейбук необходимо запускать только если freeradius требуется установить в виде сервиса. Если freeradius необходим в виде docker-контенейра, то запускать плейбук не нужно, он будет установлен во время разворачивания NAICE.
>
> За переключение режима установки отвечает переменная `deb_radius`, значение по умолчанию - `False`. Измените значение переменной перед запуском плейбука на `True`.

Перед запуском следует выполнить следующие шаги:
-  Поднять вирт. машину с ubuntu 22.04 (чтоб не раскатывать на свой хост)
-  Установить ssh server для ansible 
-  Создать свои файлы ansible.cfg, hosts.yml для ansible и прописать настройки
-  Проверить из ubuntu доступность (ping) MS AD (172.16.4.115) - Целевой настроенный MS AD под интеграцию
-  Проверить из ubuntu разрешение доменного имени (например, ping WS.LOC). Настроить DNS при отсутствии разрешения.
-  Создать пользователя для kerberos в MS AD (http://opennebula.eltex.loc:9869/#vms-tab/65). 
Диспетчер серверов -> Пункт меню "Средства" -> Пользователи и компьютеры Active Directory
(создать и добавить к нему группу Администратор) 
-  Запустить сервисы naice, включая БД
-  Прописать в файле group_vars/all.yml значение переменной `deb_radius: True`
-  Прописать в файле group_vars/all.yml в секции "Основные параметры для radius" свои значения в параметры.
Можно воспользоваться описанием переменных в файле freeradius/defaults/main.yml


Обычная установка
```
ansible-playbook -K common-freeradius.yml -i hosts.yml
```

Установка при необходимости интеграции с MS AD
```
ansible-playbook -K common-freeradius.yml -i hosts.yml -e "use-ms-ad=true"
```
Также значение переменной `use-ms-ad` можно указать в [group_vars/all.yml](group_vars/all.yml).  
Требуется настройка параметров подключения в секции *"Настройка подключения radius к MS AD"*.

Установка на определенный хост из списка (с аргументом)
```
ansible-playbook -K common-freeradius.yml -i hosts.yml -e "working_host=test_kl"
```

По результату работы скрипта поднимется freeradius сервер с подключенным postgresql и rest модулем.

* Тестовые данные из FreeRadius: пользователь из файла freeradius/files/authorize (test-user (для ping))

Проверить можно на своей машине командой на тестовых данных:

```
sudo apt install freeradius-utils // если не установлено

radtest test-user hello 10.25.96.80 1812 testing123!
```

Срок действия используемых сертификатов можно проверить так:
```
$ openssl x509 -in roles/freeradius/files/trusted_server.crt -text -noout
Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number:
            28:98:2c:c3:0f:20:23:a9:57:6b:3e:3b
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: C = BE, O = GlobalSign nv-sa, CN = AlphaSSL CA - SHA256 - G4
        Validity
            Not Before: Dec 12 07:17:17 2023 GMT
            Not After : Jan 12 07:17:16 2025 GMT
        Subject: CN = radius.eltex.nsk.ru
        Subject Public Key Info:
```

## Keycloak (Deprecated: Не используется)

Для установки запустить скрипт из директории ansible:

```
ansible-playbook --ask-become-pass common-keycloak.yml
```

По результату выполнения можно зайти в админку keycloak по адресу http://10.25.96.80:8080/. В качестве тестовых данных 
создан realm Gavia с пользователем test/test.

Для проверки интеграции можно запустить тестовый сервис naice-sandbox/keycloak-example. После запуска сервиса перейти 
по ссылке http://localhost:8081/home и если все сконфигурировано правильно, то произойдет редирект на авторизацию через
keycloak.

## NAICE databases

Для создания пользователей для сервисов, баз данных и выдачи прав на БД запустить скрипт из директории ansible:

```
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml
```
Для установки на произвольную VM ее надо добавить в hosts.yml и при запуске скрипта указать:
```bash
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml -e "working_host=test_kl"

для просмотра хостов, на которых будет запущен скрипт:
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml -e "working_host=test_kl" --list-hosts
```

По результату в postgresql должны быть созданы БД и пользователи.

Для проверки можно создать в соответствующей БД таблицу и проверить выданные права для пользователя с помощью команды:

```
SELECT * FROM information_schema.table_privileges;
```

## Deploy naice services

Для деплоя сервисов NAICE необходимо выполнить скрипт **common-naice-services.yml**. 
```bash
только спросить :)
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml --check

накатить
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml
```

Для выполнения скрипта на произвольной VM необходимо добавить в **hosts.yml** описание своей VM и указать её при запуске скрипта:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "working_host=test_kl"
```

Для того что бы увидеть на каких хостах будет выполнятся скрипт:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml --list-hosts

или
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "working_host=test_kl" --list-hosts
```

В скрипте поддержана возможность выполнить установку вместе с СУБД postgresql в докере или использовать ранее установленную СУБД postgresql.
Установка с использованием существующей СУБД:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "deb_postgres=True"

на произвольный хост:
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "deb_postgres=True working_host=test_kl"
```
В случае установки с использованием существующей СУБД её необходимо *предварительно* развернуть используя скрипт **common-naice-databases.yml**.

Аналогично возможна установка отдельного сервиса freeradius с помощью **common-freeradius.yml**. Установку необходимо производить *после* разворачивания NAICE, см. [FreeRadius](#FreeRadius).

Описание переменных:

| Variable nane                | Description                                              |
|------------------------------|----------------------------------------------------------|
| version_tag                  | Тэг докер образов, обычно это имя ветки или номер версии |
| gavia_port                   | Gavia service port                                       |
| gavia_host_port              | Gavia host port                                          |
| gavia_implementation_version | Implementation version of gavia                          |
| lemmus_port                  | Lemmus service port                                      |
| lemmus_host_port             | Lemmus host port                                         |
| lemmus_postgres_username     | Username for postgresql connection                       |
| lemmus_postgres_password     | Password for postgresql connection                       |
| lemmus_issuer_url            | Uri of issuer for OAuth 2.0 code flow                    | 
| lemmus_redirects             | List of not protected endpoint for OAuth 2.0 code flow   |
| lemmus_access_ttl_s          | Time to live of access token in seconds                  |
| lemmus_refresh_ttl_s         | Time to live of refresh token in seconds                 |
| ursus_port                   | Ursus service port                                       |
| ursus_host_port              | Ursus host port                                          |
| ursus_grpc_port              | Grpc service port                                        |
| ursus_grpc_host_port         | Grpc service host port                                   |
| ursus_postgres_username      | Username for postgresql connection                       |
| ursus_postgres_password      | Password for postgresql connection                       |
| ursus_postgres_jdbc_url      | Connection to postgres url                               |
| ursus_update_oui_time        | The oui file upload period                               |
| ursus_upload_oui_csv         | Enables or disables the oui download mode                |
| ursus_upload_csv_oui_url     | The address where the oui file will be received          |
| ovis_cache_ttl_s             | Time to live for Ovis cache in seconds                   |
| ovis_session_idle_s          | Idle time for sessions in Ovis in seconds                |

Пример развёрнутых сервисов:
```
/etc/docker-naice$ docker compose ps
NAME             IMAGE                                  COMMAND                                                                        SERVICE        CREATED         STATUS         PORTS
naice-gavia      lab3.eltex.loc:5000/naice-gavia:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.gavia.GaviaApplication"     naice-gavia    12 hours ago    Up 2 minutes   0.0.0.0:8080->8080/tcp, :::8080->8080/tcp
naice-lemmus     lab3.eltex.loc:5000/naice-lemmus:0.4   "java -cp @/app/jib-classpath-file org.eltex.naice.lemmus.LemmusApplication"   naice-lemmus   12 hours ago    Up 2 minutes   0.0.0.0:8083->8083/tcp, :::8083->8083/tcp
naice-postgres   nexus.eltex.loc:4432/postgres:15       "docker-entrypoint.sh postgres"                                                postgres       12 hours ago    Up 2 minutes   0.0.0.0:5432->5432/tcp, :::5432->5432/tcp
naice-ursus      lab3.eltex.loc:5000/naice-ursus:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.ursus.UrsusApplication"     naice-ursus    12 hours ago    Up 2 minutes   0.0.0.0:8081-8082->8081-8082/tcp, :::8081-8082->8081-8082/tcp
naice-web        lab3.eltex.loc:5000/naice-web:0.4      "/docker-entrypoint.sh nginx -g 'daemon off;'"                                 naice-web      2 minutes ago   Up 2 minutes   80/tcp, 0.0.0.0:4200->4200/tcp, :::4200->4200/tcp
```

Внимание! Docker ставить заранее не надо. Все, что нужно скрипт установит сам. А с программами, установленными, другим способом Ansible может и не справиться. При возникновении ошибки придётся удалить старый Docker и позволить Ansible сделать всё с начала.

## Восстановление дефолтного администратора

Если понадобиться восстановить дефолтного администратора (логин - *admin*, пароль - *admin*), - создать его заново, вернуть дефолтный пароль или включить, если он был выключен, - то для этого нужно запустить скрипт **restore-default-admin.yml**
```bash
ansible-playbook restore-default-admin.yml -i hosts.yml -e "working_host=lab516"
```

Скрипт добавляет в БД дефолтного администратора, если данной учетной записи нет в базе. Если же учетная запись с логином admin уже существует,
то скрипт принудительно меняет пароль на admin и устанавливает для учетной записи статус "Включено".  
Другие учетные данные, такие как email или описание, не меняются.

Для работы плейбука потребуется установить коллекцию Ansible:
```bash
ansible-galaxy collection install community.postgresql
```

Если же это не сработает, то возможно потребуется добавить в команду флаг --force:
```bash
ansible-galaxy collection install community.postgresql --force
```

Если при запуске скрипта возникает такая ошибка
```
TASK [postgresql : Insert default administrator with login 'admin', password 'admin'] *********************************************************************************
fatal: [test_kl]: FAILED! => {"ansible_facts": {"discovered_interpreter_python": "/usr/bin/python3"}, "changed": false, "msg": "Failed to import the required Python library (psycopg2) on localhost.localdomain's Python /usr/bin/python3. Please read the module documentation and install it in the appropriate location. If the required library is installed, but Ansible is using the wrong Python interpreter, please consult the documentation on ansible_python_interpreter"}
...ignoring
```
То необходимо дополнительно установить библиотеку psycopg2-binary для python на локальном хосте, где запускается ansible и на удаленном.
```bash
sudo pip3 install psycopg2-binary.
```

## Мониторинг

Для установки системы мониторинга (на данный момент - *pgwatch2* + *eltex-radius-exporter* + *Cadvisor* + *node-exporter* + *Prometheus* + *Grafana*) можно воспользоваться плейбуком `install-monitoring.yml`. Он установит перечисленные выше сервисы в docker (а также сам docker при использовании тега `install-docker`) на ВМ, указанной в `hosts.yml` как `node_who_monitor`, а в качестве цели для мониторинга будет установлены хосты `node_with_freeradius`, `node_with_postgres`, `node_with_naice`.

Для работы плейбука потребуется установить коллекцию Ansible:
```bash
ansible-galaxy collection install community.postgresql
```

Для того, чтобы *eltex-radius-exporter* мог получить метрики *freeradius*, редактируется конфигурационный файл [`status`](https://wiki.freeradius.org/config/Status). Если freeradius **установлен как сервис** на хосте `node_with_freeradius`, то для подготовки его к мониторингу запустите плейбук с переменной `deb_radius=True`:
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml -e "deb_radius=True"
```
Для radius в docker данная подготовка уже выполнена и экспортер метрик установлен внутри контейнера, запуск плейбука не требуется.

Если *Postgresql* **установлен как сервис** (не в docker), то необходимо выполнить действия по предварительной подготовки БД к мониторингу, которые запускаются при значении переменной `deb_postgres=True`. Для Postgresql в docker используется специальный docker image, где эта подготовка выполнена.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml -e "deb_postgres=True"
```

По умолчанию, без тегов, выполняется установка только системы мониторинга, без подготовки Freeradius и Postgresql.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml
```

Однако если установка выполняется на чистую машину, где не установлен докер, то нужно устанавливать с тегом `install-docker`.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml --tags="install-docker"
```

Для того, чтобы указать цели для мониторинга pgwatch2 (мониторинг Postgres), требуется указать все данные для подключения в web-интерфейсе настройки по адресу http://IP-адрес-хоста-мониторинга:порт-pgwatch2-web

Описание переменных:
| Variable name                | Default value                 | Description                                                          |
|------------------------------|-------------------------------|----------------------------------------------------------------------|
| naice_monitoring_docker_path | /etc/docker-naice/monitoring/ | Путь для установки сервисов мониторинга и их конфигурационных файлов |
| radius_exporter_version      | 1.27-96                       | Версия сервиса eltex-radius-exporter                                 |
| radius_exporter_port         | 9812                          | Порт, на котором будут отдаваться метрики от eltex-radius-exporter   |
| radius_status_host           | 127.0.0.1                     | Адрес, с которого freeradius отдает данные для метрик                |
| radius_status_port           | 18123                         | Порт, с которого freeradius отдает данные для метрик                 |
| radius_client_host           | *                             | Адрес, с которого eltex-radius-exporter опрашивает freeradius        |
| radius_secret                | eltex                         | Secret для взаимодействия freeradius - radius-exporter               |
| prometheus_version           | latest                        | Версия Prometheus                                                    |
| prometheus_port              | 9090                          | Порт, на котором работает Prometheus                                 |
| node_exporter_version        | latest                        | Версия Node Exporter                                                 | 
| node_exporter_port           | 9100                          | Порт, на котором работает Node Exporter                              |
| grafana_version              | latest                        | Версия Grafana                                                       |
| grafana_port                 | 3000                          | Порт, на котором работает Grafana                                    |
| cadvisor_version             | latest                        | Версия Cadvisor (мониторинг docker)                                  |
| cadvisor_port                | 9200                          | Порт, на котором работает Cadvisor                                   |
| postgres_login_host          | 127.0.0.1                     | Хост для подключения к Postgres c хоста под мониторингом             | 
| postgres_login_user          | ursus                         | Пользователь для подключения к Postgres                              |
| postgres_login_password      | ursus                         | Пароль пользователя для подключения к Postgres                       |
| postgres_login_db            | ursus                         | БД для подключения к Postgres                                        |
| postgres_mon_user_login      | pgwatch2                      | Пользователь для мониторинга                                         |
| postgres_mon_user_password   | secret                        | Пароль пользователя для мониторинга                                  |
| postgres_mon_user_conn_limit | 3                             | Максимальное количество подключений пользователя для мониторинга     |
| postgres_dbs_for_mon         | ['postgres', 'ursus']         | БД, которые необходимо мониторить                                    |
| pgwatch2_version             | latest                        | Версия pgwatch2                                                      |
| pgwatch2_grafana_port        | 3001                          | Порт, на котором работает Grafana с дашбордами pgwatch2              |
| pgwatch2_web_port            | 9080                          | Порт, на котором работает web-интерфейс настройки pgwatch2           |

Описание тегов при запуске плейбука:
| Tag name            | Condition to use               | Description                                                        |
|---------------------|--------------------------------|--------------------------------------------------------------------|
| install-docker      | не установлен docker compose   | - Установка docker compose на сервер мониторинга <br> - Старт контейнеров с сервисами для мониторинга через docker compose                    |
| без тегов           | - radius и postgres в докере <br> - установлен docker compose      | Старт контейнеров с сервисами для мониторинга через docker compose | 


# Решение проблем

| Проблема                                            | Решение                                                                        |
|-----------------------------------------------------|--------------------------------------------------------------------------------|
| Ansible не видит хосты для взаимодействия <br> `[WARNING]: provided hosts list is empty, only localhost is available. Note that the implicit localhost does not match 'all'` | Укажите явно путь до файла hosts.yml через `-i /path/to/hosts.yml`
| Дашборды не отображаются в списке дашбордов Grafana | Импортируйте их вручную из `./ansible/roles/monitoring/files/*-dashboard.json` |


# Секреты IDEA

## Schema mapping

Для работы в IntelliJ IDEA с кодом на YAML можно настроить схему. Активная схема отображается в нижнем правом углу IDE.

Настраивается в File - Settings. Примерно так можно разметить для себя все типы файлов.

![Ansible schema mapping](pic/ansible_schema_mapping.png)

