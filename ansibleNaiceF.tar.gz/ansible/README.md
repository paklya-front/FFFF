# Об Ansible

[Можно почитать тут](https://gitlab.eltex.loc/ems-group/softwlc/tools/ansible)

# Установка Ansible
[Установка Ansible]
(https://docs.ansible.com/ansible/latest/installation_guide/installation_distros.html)

(https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html)


# Запуск Ansible

Для подключения по SSH Ansible может использовать ключи SSH или пароли.
Если используется авторизация по ключам - их нужно предварительно забросить на ту машину, которой вы собираетесь управлять.

Сделать это можно вот так. Нужно будет ввести свой пароль.
```
$ ssh-copy-id -i ~/.ssh/eltex.pub mikhail_gaydamaka@10.25.96.80
...
Now try logging into the machine, with:   "ssh 'mikhail_gaydamaka@10.25.96.80'"
and check to make sure that only the key(s) you wanted were added.
```
После этого команда `ssh mikhail_gaydamaka@10.25.96.80` будет проходить без запроса пароля.

Создать ключ можно так
```
ssh-keygen -t rsa -b 4096 -C "mikhail.gaydamaka@eltex.loc"
```

Если вы используете Asbru Connection Manager, настройке в соединении Authentication, Private key и укажите путь к `/.ssh/eltex`.

На сервере должен присутствовать sudo, а пользователь, от имени которого будет выполняться установка, должен быть в группе sudo.

Так же необходимо создать файл с настройками ansible.cfg в корневой директории ansible. Пример можно посмотреть в ansible.cfg.template.
Создать можно путем копирования шаблона в папке с полейбуками ansible:
```bash
cp -v ansible.cfg.template ansible.cfg
```
Потребуется ракоментировать и изменить переменную private_key_file:
```
private_key_file = <полный путь к файлу публичного ключа SSH, включая имя файла>
```
В переменной remote_user указать имя пользователя под которым будет выполняться подключение к удаленному хосту:
```
remote_user = <имя пользователя>
```

Адрес машины (сервера или виртуалки) указывает в отдельном файле [hosts.yml](hosts.yml). Все хосты разделены на группы. 
Группа `common` - параметры подключения к хосту при выполнении stand-alone установки.
Группа `monitoring` - параметры подключения к хостам для установки системы мониторинга (только для stand-alone установки).
Группа `reservation` - параметры подключения к хостам при выполнении установки сервисов NAICE с резервированием.
Группа `postgres-cluster` - параметры подключения к хостам при выполнении установки СУБД PostgreSQL с резервированием.

Если планируется использовать при SSH подключении доступ по логину / паролю - необходимо в файле hosts.yml указать переменные для группы хостов. на которые будет проиводиться установка:
```
ansible_user: <логин пользователя для входа на удаленный хост>
```
```
ansible_ssh_pass: <пароль пользователя для входа на удаленный хост>
```
```
ansible_become_password: <пароль sudo пользователя при выполнении команд на удаленном хосте>
```

# Установка NAICE

[Инструкция по установке NAICE (v0.5)](https://docs.eltex-co.ru/pages/viewpage.action?pageId=488734820)

> **Кратко**
>
> Для разворачивания системы NAICE необходимо запустить несколько ansible-плейбуков на один целевой хост в следующей последовательности: 
>
>- `common-naice-databases.yml`  \*
>- `common-naice-services.yml`
>
> \* Если БД необходимо установить в виде сервиса. Для запуска БД в docker запуск этого плейбука не требуется.
>
> Перед запуском плейбуков не забудьте указать параметры доступа к целевому хосту в [hosts.yml](hosts.yml) и изменить необходимые параметры развертывания в переменных [group_vars/all.yml](group_vars/all.yml).


# Сборник рецептов Ansible

Все скрипты тестируются на Ubuntu

## Проверка перед стартом

Взял отсюда [docs.ansible.com](https://docs.ansible.com/ansible/latest/getting_started/index.html)

* `ansible --version`
* `ansible-playbook --version` - Check out version installed
* `ansible all --list-hosts` - Verify the hosts in your inventory
* `ansible all -m ping` - Ping the managed nodes

## Информация о состоянии системы

Этот Playbook просто выводит время в системе, статус сервисов и т.д.

Может запускаться как проверочный, потому что ничего не модифицирует. Однако работать без ошибок он будет, когда всё окружение уже установлено. Плюс скрипт содержит избыточный набор модулей, не все из которых уже официально входят в решение NAICE.

```
$ ansible-playbook common-info.yml
```

Для отображения статуса сервисов используется [service_facts модуль](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/service_facts_module.html)

## NTP, timezone

[This module](https://docs.ansible.com/ansible/latest/collections/community/general/timezone_module.html) 
is part of the community.general collection (version 6.5.0).

Установка зависимостей
```
ansible-galaxy collection install community.general
```
Установить таймзону, NTP сервер, распечатать дату и время:
```
ansible-playbook --ask-become-pass common-ntp.yml
```

## NAICE databases

Для создания пользователей для сервисов, баз данных и выдачи прав на БД запустить скрипт из директории ansible:

```
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml
```
Для установки на произвольную VM ее надо добавить в hosts.yml и при запуске скрипта указать:
```bash
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml -e "working_host=test_kl"

для просмотра хостов, на которых будет запущен скрипт:
ansible-playbook --ask-become-pass common-naice-databases.yml -i hosts.yml -e "working_host=test_kl" --list-hosts
```

По результату в postgresql должны быть созданы БД и пользователи.

Для проверки можно создать в соответствующей БД таблицу и проверить выданные права для пользователя с помощью команды:

```
SELECT * FROM information_schema.table_privileges;
```
## Deploy postgresql в кластере (primary + standby)
Установка кластеризованного postgresql на 2 хоста c репликацией через repmgr.
Есть 2 варианта инсталляции - с docker и без него. В обоих случаях будут использована информация о нодах из секции ```postgres-cluster``` файла [ hosts.yml](hosts.yml) 

### - Пакетная установка без Docker 
 Для установки без docker используем playbook: ```common-postgres-cluster.yml```

- Документация в confluence: [Настройка Repmgr 5.4.1 Primary + Standby (Без docker)](https://intdocs.eltex.loc/pages/viewpage.action?pageId=147214673)
- Документация про данный playbook: [roles/postgresql-replication/README.md](roles/postgresql-replication/README.MD)

### - Установка через Docker-образы
Для установки через docker-образы используем playbook: ```docker-postgres-cluster.yml```


## Deploy naice services

Для деплоя сервисов NAICE необходимо выполнить скрипт **common-naice-services.yml**. 
```bash
только спросить :)
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml --check

накатить
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml
```

Для выполнения скрипта на произвольной VM необходимо добавить в **hosts.yml** описание своей VM и указать её при запуске скрипта:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "working_host=test_kl"
```

Для того что бы увидеть на каких хостах будет выполнятся скрипт:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml --list-hosts

или
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "working_host=test_kl" --list-hosts
```

В скрипте поддержана возможность выполнить установку вместе с СУБД postgresql в докере или использовать ранее установленную СУБД postgresql.
Установка с использованием существующей СУБД:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "externally_installed_postgres=True"

на произвольный хост:
ansible-playbook --ask-become-pass common-naice-services.yml -i hosts.yml -e "externally_installed_postgres=True working_host=test_kl"
```
В случае установки с использованием существующей СУБД её необходимо *предварительно* развернуть используя скрипт **common-naice-databases.yml**.

Что бы указать адрес сервера лицензирования ELM при установке необходимо указать значение переменной "gulo_elm_server_url":
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -e "gulo_elm_server_url=https://192.168.0.1:8099"
```

Для повторной генерации сертификата для HTTPS на пользовательских интерфейсах необходимо выполнить команду:
```bash
ansible-playbook --ask-become-pass common-naice-services.yml -e "cert_update=true"
```
Это будет необходимо при смене IP-адреса сервера NAICE, если используется встроенный самоподписный сертифкат HTTPS.

Аналогично возможна установка отдельного сервиса freeradius с помощью **common-freeradius.yml**. Установку необходимо производить *после* разворачивания NAICE, см. [FreeRadius](#FreeRadius).

Описание переменных:

| Variable nane                | Description                                              |
|------------------------------|----------------------------------------------------------|
| version_tag                  | Тэг докер образов, обычно это имя ветки или номер версии |
| gavia_port                   | Gavia service port                                       |
| gavia_host_port              | Gavia host port                                          |
| gavia_implementation_version | Implementation version of gavia                          |
| lemmus_port                  | Lemmus service port                                      |
| lemmus_host_port             | Lemmus host port                                         |
| lemmus_postgres_username     | Username for postgresql connection                       |
| lemmus_postgres_password     | Password for postgresql connection                       |
| lemmus_issuer_url            | Uri of issuer for OAuth 2.0 code flow                    | 
| lemmus_redirects             | List of not protected endpoint for OAuth 2.0 code flow   |
| lemmus_access_ttl_s          | Time to live of access token in seconds                  |
| lemmus_refresh_ttl_s         | Time to live of refresh token in seconds                 |
| ursus_port                   | Ursus service port                                       |
| ursus_host_port              | Ursus host port                                          |
| ursus_grpc_port              | Grpc service port                                        |
| ursus_grpc_host_port         | Grpc service host port                                   |
| ursus_postgres_username      | Username for postgresql connection                       |
| ursus_postgres_password      | Password for postgresql connection                       |
| ursus_postgres_jdbc_url      | Connection to postgres url                               |
| ursus_update_oui_time        | The oui file upload period                               |
| ursus_upload_oui_csv         | Enables or disables the oui download mode                |
| ursus_upload_csv_oui_url     | The address where the oui file will be received          |
| ovis_cache_ttl_s             | Time to live for Ovis cache in seconds                   |
| ovis_session_idle_s          | Idle time for sessions in Ovis in seconds                |
| larus_port                   | Larus HTTP port in container (inner port)                |
| larus_host_port              | Larus HTTP port on host (outside port)                   |
| larus_https_port             | Larus HTTPS port                                         |
| cert_path: https             | Путь к папке с сертификатом для HTTPS на интерфейсах     |
| key_password                 | Пароль к ключу сертификата https                         |
| cert_update                  | Обновлять сертификат, если он уже есть                   |

Пример развёрнутых сервисов:
```
/etc/docker-naice$ docker compose ps
NAME             IMAGE                                  COMMAND                                                                        SERVICE        CREATED         STATUS         PORTS
naice-gavia      lab3.eltex.loc:5000/naice-gavia:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.gavia.GaviaApplication"     naice-gavia    12 hours ago    Up 2 minutes   0.0.0.0:8080->8080/tcp, :::8080->8080/tcp
naice-lemmus     lab3.eltex.loc:5000/naice-lemmus:0.4   "java -cp @/app/jib-classpath-file org.eltex.naice.lemmus.LemmusApplication"   naice-lemmus   12 hours ago    Up 2 minutes   0.0.0.0:8083->8083/tcp, :::8083->8083/tcp
naice-postgres   nexus.eltex.loc:4432/postgres:15       "docker-entrypoint.sh postgres"                                                postgres       12 hours ago    Up 2 minutes   0.0.0.0:5432->5432/tcp, :::5432->5432/tcp
naice-ursus      lab3.eltex.loc:5000/naice-ursus:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.ursus.UrsusApplication"     naice-ursus    12 hours ago    Up 2 minutes   0.0.0.0:8081-8082->8081-8082/tcp, :::8081-8082->8081-8082/tcp
naice-web        lab3.eltex.loc:5000/naice-web:0.4      "/docker-entrypoint.sh nginx -g 'daemon off;'"                                 naice-web      2 minutes ago   Up 2 minutes   80/tcp, 0.0.0.0:4200->4200/tcp, :::4200->4200/tcp
```

Внимание! Docker ставить заранее не надо. Все, что нужно скрипт установит сам. А с программами, установленными, другим способом Ansible может и не справиться. При возникновении ошибки придётся удалить старый Docker и позволить Ansible сделать всё с начала.

## Deploy reserved naice services

Плейбук [reservation-naice-services.yml](reservation-naice-services.yml) разворачивает NAICE на двух хостах, взаимодействие с которыми проходит через Virtual IP настроенный через keepalived. 

Перед запуском плейбука для разворачивания NAICE с резервированием нужно указать параметры доступа к целевым хостам
в [hosts.yml](hosts.yml) и изменить переменные в [reservation.yml](./group_vars/reservation.yml)
и [all.yml](./group_vars/all.yml).
Плейбук работает строго для двух хостов с именами **"master_host"** и **"backup_host"** находящихся в группе **"reservation"**.
> **Важно**
>
> Резервирование nats и hazelcast будет производиться по ip указанным в ansible_host, поэтому на сетевых интерфейсах 
> этих ip должны быть открыты порты для доступа сервисов (по умолчанию 5701, 5702, 6222).  


Для деплоя сервисов NAICE c резервированием необходимо выполнить скрипт **reservation-naice-services.yml**.

```bash
ansible-playbook --ask-become-pass reservation-naice-services.yml -i hosts.yml
```

Для того что бы увидеть на каких хостах будет выполнятся скрипт:

```bash
ansible-playbook --ask-become-pass reservation-naice-services.yml -i hosts.yml --list-hosts
```

Установка возможна только с использованием существующей СУБД, её необходимо *предварительно* развернуть используя скрипт
**common-naice-databases.yml** или **common-postgres-cluster.yml**.

Что бы указать адрес сервера лицензирования ELM при установке необходимо указать значение переменной "gulo_elm_server_url":

```bash
ansible-playbook --ask-become-pass reservation-naice-services.yml -e "gulo_elm_server_url=https://192.168.0.1:8099"
```

Для повторной генерации сертификата для HTTPS на пользовательских интерфейсах необходимо выполнить команду:

```bash
ansible-playbook --ask-become-pass reservation-naice-services.yml -e "cert_update=true"
```

Это будет необходимо при смене IP-адреса сервера NAICE, если используется встроенный самоподписный сертифкат HTTPS.
Если есть необходимость использовать определенный сертификат нужно обратиться к [инструкции](./roles/https/README.md).

> **Внимание**
>
> Сертификат должен указывать на Virtual IP, через который будут работать сервисы.
>
> Генерация сертификатов производится через роль [self-signed-cert](./roles/https/README.md), поэтому его
> настройки актуальны и для этого плейбука


Возможна установка отдельного сервиса freeradius с помощью **common-freeradius.yml**. Установку необходимо производить
*после* разворачивания NAICE, см. [FreeRadius](#FreeRadius).

Описание переменных:

### all.yml

| Variable nane                | Description                                              |
|------------------------------|----------------------------------------------------------|
| version_tag                  | Тэг докер образов, обычно это имя ветки или номер версии |
| gavia_port                   | Gavia service port                                       |
| gavia_host_port              | Gavia host port                                          |
| gavia_implementation_version | Implementation version of gavia                          |
| lemmus_port                  | Lemmus service port                                      |
| lemmus_host_port             | Lemmus host port                                         |
| lemmus_postgres_username     | Username for postgresql connection                       |
| lemmus_postgres_password     | Password for postgresql connection                       |
| lemmus_issuer_url            | Uri of issuer for OAuth 2.0 code flow                    | 
| lemmus_redirects             | List of not protected endpoint for OAuth 2.0 code flow   |
| lemmus_access_ttl_s          | Time to live of access token in seconds                  |
| lemmus_refresh_ttl_s         | Time to live of refresh token in seconds                 |
| ursus_port                   | Ursus service port                                       |
| ursus_host_port              | Ursus host port                                          |
| ursus_grpc_port              | Grpc service port                                        |
| ursus_grpc_host_port         | Grpc service host port                                   |
| ursus_postgres_username      | Username for postgresql connection                       |
| ursus_postgres_password      | Password for postgresql connection                       |
| ursus_postgres_jdbc_url      | Connection to postgres url                               |
| ursus_update_oui_time        | The oui file upload period                               |
| ursus_upload_oui_csv         | Enables or disables the oui download mode                |
| ursus_upload_csv_oui_url     | The address where the oui file will be received          |
| ovis_cache_ttl_s             | Time to live for Ovis cache in seconds                   |
| ovis_session_idle_s          | Idle time for sessions in Ovis in seconds                |
| larus_port                   | Larus HTTP port in container (inner port)                |
| larus_host_port              | Larus HTTP port on host (outside port)                   |
| larus_https_port             | Larus HTTPS port                                         |
| cert_path: https             | путь к папке с сертифкатом для HTTPS на интерфейсах      |
| key_password                 | пароль к ключу сертификата https                         |
| cert_update                  | обновлять сертифкат, если он уже есть                    |

### reservation.yml

| Variable nane                              | Description                                                                                                                                                                                                       |
|--------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| check_vip_interface                        | Проверять ли корректность интерфейса на который ставится VIP и соответствие VIP маске подсети                                                                                                                     |
| vip_server_name                            | Переопределяет server_name для роли self-signed-cert (Имя субъекта для которого выдан сертификат (CN))                                                                                                            |
| vip_auth_type                              | Тип аутентификации PASS/AH (AH не рекомендуется)                                                                                                                                                                  |
| vip_auth_pass                              | Пароль для доступа к vrrp (используется только первые 8 символов)                                                                                                                                                 |
| vrrp_garp_master_refresh                   | Минимальный интервал времени для обновления ARP во время работы MASTER (в секундах)                                                                                                                               |
| vrrp_garp_master_refresh_repeat            | Количество ARP-сообщений, отправляемых одновременно во время работы мастера                                                                                                                                       |
| vrrp_garp_master_delay                     | Задержка для второго набора ARP после перехода на MASTER (в секундах)                                                                                                                                             |
| vrrp_garp_master_repeat                    | Количество ARP-сообщений, отправляемых после перехода на MASTER                                                                                                                                                   |
| virtual_router_id                          | Произвольный уникальный номер от 1 до 255, используемый для различения нескольких экземпляров vrrpd, <br/>работающих на одном сетевом интерфейсе и семействе адресов, а также многоадресной/одноадресной рассылки |
| advert_int                                 | Интервал в секундах (например 0.92), с которым MASTER сообщает о себе широковещательным уведомлением                                                                                                              |
| check_interval                             | Интервал времени, через который будет проверяться состояние сервисов (в секундах)                                                                                                                                 |
| keepailveed_logrotate_save_n_rotated_files | Хранить последние N ротированных файлов. Остальные удалять.                                                                                                                                                       |
| keepailveed_logrotate_maxage               | Хранить ротированные файлы за последние N дней. Остальные удалять.                                                                                                                                                |
| keepailveed_logrotate_size                 | Максимальный размер файла, при достижении которого ротация начнётся независимо от расписания по времени<br/>1 - 1 байт, 1k - 1 килобайт, 1M - 1 мегабайт, 1G - 1 гигабайт                                         |
| keepailveed_logrotate_delay                | Период ротации логов (hourly, daily, weekly, monthly, yearly)                                                                                                                                                     |
| vulpus_grpc_service_address                | Адрес сервиса vulpus (по умолчанию установлен keepalived_vip)                                                                                                                                                     |
| gulo_grpc_service_address                  | Адрес сервиса gulo (по умолчанию установлен keepalived_vip)                                                                                                                                                       |

Пример развёрнутых сервисов:

```
/etc/docker-naice$ docker compose ps
NAME             IMAGE                                  COMMAND                                                                        SERVICE        CREATED         STATUS         PORTS
naice-gavia      lab3.eltex.loc:5000/naice-gavia:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.gavia.GaviaApplication"     naice-gavia    12 hours ago    Up 2 minutes   0.0.0.0:8080->8080/tcp, :::8080->8080/tcp
naice-lemmus     lab3.eltex.loc:5000/naice-lemmus:0.4   "java -cp @/app/jib-classpath-file org.eltex.naice.lemmus.LemmusApplication"   naice-lemmus   12 hours ago    Up 2 minutes   0.0.0.0:8083->8083/tcp, :::8083->8083/tcp
naice-postgres   nexus.eltex.loc:4432/postgres:15       "docker-entrypoint.sh postgres"                                                postgres       12 hours ago    Up 2 minutes   0.0.0.0:5432->5432/tcp, :::5432->5432/tcp
naice-ursus      lab3.eltex.loc:5000/naice-ursus:0.4    "java -cp @/app/jib-classpath-file org.eltex.naice.ursus.UrsusApplication"     naice-ursus    12 hours ago    Up 2 minutes   0.0.0.0:8081-8082->8081-8082/tcp, :::8081-8082->8081-8082/tcp
naice-web        lab3.eltex.loc:5000/naice-web:0.4      "/docker-entrypoint.sh nginx -g 'daemon off;'"                                 naice-web      2 minutes ago   Up 2 minutes   80/tcp, 0.0.0.0:4200->4200/tcp, :::4200->4200/tcp
```

## Восстановление дефолтного администратора

> Для корректной работы данного скрипта, требуется установленная версия библиотеки psycopg2 для python3

Если понадобиться восстановить дефолтного администратора (логин - *admin*, пароль - *admin*), - создать его заново, вернуть дефолтный пароль или включить, если он был выключен, - то для этого нужно запустить скрипт **restore-default-admin.yml**
```bash
ansible-playbook restore-default-admin.yml -i hosts.yml -e "working_host=lab516"
```

Скрипт добавляет в БД дефолтного администратора, если данной учетной записи нет в базе. Если же учетная запись с логином admin уже существует,
то скрипт принудительно меняет пароль на admin и устанавливает для учетной записи статус "Включено".  
Другие учетные данные, такие как email или описание, не меняются.

Для работы плейбука потребуется установить коллекцию Ansible:
```bash
ansible-galaxy collection install community.postgresql
```

Если же это не сработает, то возможно потребуется добавить в команду флаг --force:
```bash
ansible-galaxy collection install community.postgresql --force
```

## Мониторинг

Для установки системы мониторинга (на данный момент - *pgwatch2* + *eltex-radius-exporter* + *Cadvisor* + *node-exporter* + *Prometheus* + *Grafana*) можно воспользоваться плейбуком `install-monitoring.yml`. Он установит перечисленные выше сервисы в docker (а также сам docker при использовании тега `install-docker`) на ВМ, указанной в `hosts.yml` как `node_who_monitor`, а в качестве цели для мониторинга будет установлены хосты `node_with_postgres` и `node_with_naice`.

Для работы плейбука потребуется установить коллекцию Ansible:
```bash
ansible-galaxy collection install community.postgresql
```

Если *Postgresql* **установлен как сервис** (не в docker), то необходимо выполнить действия по предварительной подготовки БД к мониторингу, которые запускаются при значении переменной `externally_installed_postgres=True`. Для Postgresql в docker используется специальный docker image, где эта подготовка выполнена.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml -e "externally_installed_postgres=True"
```

По умолчанию, без тегов, выполняется установка только системы мониторинга, без подготовки Postgresql.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml
```

Однако если установка выполняется на чистую машину, где не установлен докер, то нужно устанавливать с тегом `install-docker`.
```bash
ansible-playbook --ask-become-pass install-monitoring.yml -i hosts.yml --tags="install-docker"
```

Для того, чтобы указать цели для мониторинга pgwatch2 (мониторинг Postgres), требуется указать все данные для подключения в web-интерфейсе настройки по адресу http://IP-адрес-хоста-мониторинга:порт-pgwatch2-web

Описание переменных:
| Variable name                | Default value                 | Description                                                          |
|------------------------------|-------------------------------|----------------------------------------------------------------------|
| naice_monitoring_docker_path | /etc/docker-naice/monitoring/ | Путь для установки сервисов мониторинга и их конфигурационных файлов |
| radius_exporter_port         | 9812                          | Порт, на котором будут отдаваться метрики от eltex-radius-exporter   |
| radius_secret                | eltex                         | Secret для взаимодействия freeradius - radius-exporter               |
| prometheus_version           | latest                        | Версия Prometheus                                                    |
| prometheus_port              | 9090                          | Порт, на котором работает Prometheus                                 |
| node_exporter_version        | latest                        | Версия Node Exporter                                                 | 
| node_exporter_port           | 9100                          | Порт, на котором работает Node Exporter                              |
| grafana_version              | latest                        | Версия Grafana                                                       |
| grafana_port                 | 3000                          | Порт, на котором работает Grafana                                    |
| cadvisor_version             | latest                        | Версия Cadvisor (мониторинг docker)                                  |
| cadvisor_port                | 9200                          | Порт, на котором работает Cadvisor                                   |
| postgres_login_host          | 127.0.0.1                     | Хост для подключения к Postgres c хоста под мониторингом             | 
| postgres_login_user          | ursus                         | Пользователь для подключения к Postgres                              |
| postgres_login_password      | ursus                         | Пароль пользователя для подключения к Postgres                       |
| postgres_login_db            | ursus                         | БД для подключения к Postgres                                        |
| postgres_mon_user_login      | pgwatch2                      | Пользователь для мониторинга                                         |
| postgres_mon_user_password   | secret                        | Пароль пользователя для мониторинга                                  |
| postgres_mon_user_conn_limit | 3                             | Максимальное количество подключений пользователя для мониторинга     |
| postgres_dbs_for_mon         | ['postgres', 'ursus']         | БД, которые необходимо мониторить                                    |
| pgwatch2_version             | latest                        | Версия pgwatch2                                                      |
| pgwatch2_grafana_port        | 3001                          | Порт, на котором работает Grafana с дашбордами pgwatch2              |
| pgwatch2_web_port            | 9080                          | Порт, на котором работает web-интерфейс настройки pgwatch2           |

Описание тегов при запуске плейбука:

| Tag name       | Condition to use                                              | Description                                                                                                                |
|----------------|---------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|
| install-docker | не установлен docker compose                                  | - Установка docker compose на сервер мониторинга <br> - Старт контейнеров с сервисами для мониторинга через docker compose |
| без тегов      | - postgres в докере <br> - установлен docker compose          | Старт контейнеров с сервисами для мониторинга через docker compose                                                         | 


# Решение проблем

| Проблема                                                                                                                                                                     | Решение                                                                        |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------|
| Ansible не видит хосты для взаимодействия <br> `[WARNING]: provided hosts list is empty, only localhost is available. Note that the implicit localhost does not match 'all'` | Укажите явно путь до файла hosts.yml через `-i /path/to/hosts.yml`             |
| Дашборды не отображаются в списке дашбордов Grafana                                                                                                                          | Импортируйте их вручную из `./ansible/roles/monitoring/files/*-dashboard.json` |


# Секреты IDEA

## Schema mapping

Для работы в IntelliJ IDEA с кодом на YAML можно настроить схему. Активная схема отображается в нижнем правом углу IDE.

Настраивается в File - Settings. Примерно так можно разметить для себя все типы файлов.

![Ansible schema mapping](pic/ansible_schema_mapping.png)

