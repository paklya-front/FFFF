#!/bin/bash

# Environment variables
export ENABLE_SCREEN_LOG="${ENABLE_SCREEN_LOG:-false}"
export LOG_PREFIX="${LOG_PREFIX:-}"
export LOG_FILE="${LOG_FILE:-}"

# Constants
RESET='\033[0m'
RED='\033[38;5;1m'
GREEN='\033[38;5;2m'
YELLOW='\033[38;5;3m'
MAGENTA='\033[38;5;5m'
CYAN='\033[38;5;6m'
BLUE='\033[38;5;4m'

# Functions

#-----------------------
# Switching on screen logging
#-----------------------
switch_on_screen_log() {
  ENABLE_SCREEN_LOG="true"
}

#-----------------------
# Set common LOG_FILE for records
#-----------------------
set_log_file() {
  if [[ -n "${*}" ]]; then
    LOG_FILE="${*}"
  fi
}


#-----------------------
# Set common LOG_PREFIX for records
#-----------------------
set_log_prefix() {
  if [[ -n "${*}" ]]; then
    LOG_PREFIX="[${*}] "
  fi
}

#-----------------------
# Log colorized message to output screen
# Output: LOG_PREFIX [DATE] MESSAGE
#-----------------------
log_to_screen() {
  [[ "${ENABLE_SCREEN_LOG}" == "true" ]] && \
  printf "%b\\n" "${CYAN}${LOG_PREFIX}${MAGENTA}[$(date "+%T.%2N] ")${RESET}${*}" >&2
}

#-----------------------
# Log message to LOG_FILE
# Output: LOG_PREFIX [DATE] MESSAGE
#-----------------------
log_to_file() {
  [[ -n "${LOG_FILE}" ]] && echo "${LOG_PREFIX}[$(date "+%T.%2N] ")${*}" >> "${LOG_FILE}"
}

#-----------------------
# Log message without level type
#-----------------------
log() {
  log_to_screen "${*}"
  log_to_file "${*}"
}
#-----------------------
# Log script output
# Output: >> MESSAGE
#-----------------------
log_script_output() {
  [[ "${ENABLE_SCREEN_LOG}" == "true" ]] && printf "%b\\n" "${BLUE}>> ${RESET} ${*}" >&2
  [[ -n "${LOG_FILE}" ]] && echo ">> ${*}" >> "${LOG_FILE}"
}

#-----------------------
# Log an 'info' message
#-----------------------
info() {
  log_to_screen "${GREEN}INFO ${RESET} ==> ${*}"
  log_to_file "INFO ==> ${*}"
}

#-----------------------
# Log an 'warn' message
#-----------------------
warn() {
  log_to_screen "${YELLOW}WARN ${RESET} ==> ${*}"
  log_to_file "WARN ==> ${*}"
}

#-----------------------
# Log an 'error' message
#-----------------------
error() {
  log_to_screen "${RED}ERROR${RESET} ==> ${*}"
  log_to_file "ERROR ==> ${*}"
}
#-----------------------
# Log a 'debug' message
#-----------------------
debug() {
  log_to_screen "${BLUE}DEBUG${RESET} ==> ${*}"
  log_to_file "DEBUG ==> ${*}"
}