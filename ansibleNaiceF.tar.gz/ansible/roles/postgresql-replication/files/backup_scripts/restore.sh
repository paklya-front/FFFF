#!/bin/bash
# Скрипт восстановления бэкапов баз данных NAICE

export OPERATIONS_LOG="${OPERATIONS_LOG:-/tmp/naice_backup.log}"
#директория с бэкапами, откуда можно взять файл
export BACKUPS_FOR_RESTORE_DIR="${BACKUPS_FOR_RESTORE_DIR:-/home/worker/backups}"
export RESTORE_DIR="${RESTORE_DIR:-/home/worker/restore}"

#------ load libraries from the same directory ----
__dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${__dir}/backup-env.sh"
. "${__dir}/liblog.sh"
. "${__dir}/libbackup.sh"

set_log_file $OPERATIONS_LOG
set_log_prefix "RESTORE"
switch_on_screen_log

#----- Проверка параметров скрипта -----
# -f - файл с бэкапом
# -d - директория с бэкапами, откуда возьмётся последний файл
restore_file=""
dir_with_backups=""
while [ "$#" -gt 0 ]; do
    case "$1" in
    -f | --file_name)
        shift
        restore_file="${1:?missing filename}"
        ;;
    -d | --dir-with-backups)
        shift
        dir_with_backups="${1:?missing directory with backups}"
        ;;
    -*)
        info "Invalid command line flag $1" >&2
        exit 1
        ;;
    esac
    shift
done

#-------- Валидация параметров ---------------
if [[ -z "${restore_file}" ]]; then
  info "Don't pass backup file via parameter (-f | --file_name)"
  if [[ -z "${dir_with_backups}" ]]; then
    info "Don't pass directory with backups via parameter (-d) => using env variable '\$BACKUPS_FOR_RESTORE_DIR:${BACKUPS_FOR_RESTORE_DIR}'"
    dir_with_backups="${BACKUPS_FOR_RESTORE_DIR}"
  fi
  restore_file=$(get_last_backup_in_directory "${dir_with_backups}")
fi
validation_backup_file "${restore_file}"

#---Проверка параметров окружения ---
info "Validation required env variables for restore"
validate_required_environment_variables "RESTORE_DIR URSUS_POSTGRES_USERNAME URSUS_POSTGRES_PASSWORD URSUS_POSTGRES_DB LEPUS_POSTGRES_USERNAME LEPUS_POSTGRES_PASSWORD LEPUS_POSTGRES_DB"

#-------- Создание директории для рестора, правка лога -----
info "Base directory for restore from env. variable '\$RESTORE_DIR:${RESTORE_DIR}'"
RESTORE_ID=$(basename $restore_file | cut -d '.' -f1)
set_log_prefix "RESTORE] [${RESTORE_ID}"
RESTORE_DIR="${RESTORE_DIR}/${RESTORE_ID}"

create_directory $RESTORE_DIR

#-------- Извлечение дампов баз -------------------
info "Extracting dumps with NAICE databases"
debug "Call 'tar -xzvf $restore_file -C $RESTORE_DIR -p'"
extract_output=$(tar -xzvf $restore_file -C $RESTORE_DIR -p)
debug $extract_output
ursus_back=$(ls -1 $RESTORE_DIR | grep "ursus")
lepus_back=$(ls -1 $RESTORE_DIR | grep "lepus")

#-- Рестор файлов --
restore_database_from_file $URSUS_POSTGRES_USERNAME $URSUS_POSTGRES_PASSWORD $URSUS_POSTGRES_DB "${RESTORE_DIR}/${ursus_back}"
restore_database_from_file $LEPUS_POSTGRES_USERNAME $LEPUS_POSTGRES_PASSWORD $LEPUS_POSTGRES_DB "${RESTORE_DIR}/${lepus_back}"

