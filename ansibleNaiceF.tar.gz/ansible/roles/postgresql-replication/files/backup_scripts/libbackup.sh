#!/bin/bash
#Library for backup/restore operations
#------------------------
# Backup database to sql file
#   $1 - db user
#   $2 - db password
#   $3 - db name
#   $4 - filename of created backup file
#------------------------
backup_database_to_file() {
    local -r db_user="${1:?missing db user}"
    local -r db_pass="${2:?missing db password}"
    local -r db_name="${3:?missing db name}"
    local -r backup_file="${4}"
    local args=("-U" "${db_user}" "-d" "${db_name}" "-f" "${backup_file}" "--inserts" "-c" "--if-exists")

    info "Starting backup of database '${db_name}' to ${backup_file}.."
    debug "Call 'PGPASSWORD=${db_pass} pg_dump ${args[*]}'"
    PGPASSWORD=$db_pass pg_dump ${args[*]} 2>&1 | { read cmd_output; log $cmd_output; }
    local err_code=${PIPESTATUS[0]}
    if [ "${err_code}" -ne 0 ]; then
      error "pg_dump return non-zero error code '${err_code}'. Exit"
      exit 1
    else
      info "Ok, backup is created."
    fi
}

#------------------------
# Restore database from sql file
#   $1 - db user
#   $2 - db password
#   $3 - db name
#   $4 - filename of created backup file
#------------------------
restore_database_from_file() {
    local -r db_user="${1:?missing db user}"
    local -r db_pass="${2:?missing db password}"
    local -r db_name="${3}"
    local -r backup_file="${4}"
    local args=("-U" "${db_user}" "-d" "${db_name}" "-a" "-f" "${backup_file}")

    info "Starting restoring of database '${db_name}' from '${backup_file}'.."
    debug "Call 'PGPASSWORD=${db_pass} psql ${args[*]}'"
    PGPASSWORD=$db_pass psql ${args[*]} 2>&1 | { while IFS= read -r line; do log_script_output $line; done }
    local err_code=${PIPESTATUS[0]}
    if [ "${err_code}" -ne 0 ]; then
      error "pg_restore returns non-zero error code '${err_code}'. Exit"
      exit 1
    else
      info "Ok, restoring is completed."
    fi
}

#------------------------
# Validation environment variables for  operation
#------------------------
validate_required_environment_variables() {
    info "Checking variables.."
    read -r -a required_vars <<<"$(tr ',;' ' ' <<<"${1}")"
    local missing_vars=()
    for i in "${required_vars[@]}"
    do
        if test -n "${!i:+y}"; then
          debug "  '${i}' = ${!i}"
        else
          debug "  '${i}' is not set"
          missing_vars+=("$i")
        fi
    done
    if [ ${#missing_vars[@]} -ne 0 ]
    then
        error "Backup/restore operation couldn't be run. The following variables are not set:"
        for i in "${missing_vars[@]}"; do log "-- ${i}"; done
        exit 1
    else
      info "Ok, all required variables are set"
    fi
}

#------------------------
# Clean old files (backups) in directory
#   $1 - directory
#   $2 - num days for saving files (30 by default)
#------------------------
clean_old_files() {
    local -r directory="${1:?missing directory``}"
    local -r days_for_save="${2:?30}"
    info "Cleaning old files from directory '${directory}"
    find $directory -mtime +$days_for_save -delete
}

#------------------------
# Get the last backup file from directory
#  $1 - directory name
# Return:
#   string - full path to a file
#------------------------
get_last_backup_in_directory() {
    local filename
    local directory="${1:?directory is required}"
    info "Trying to find the last backup file in directory '${directory}'"
    filename=$(cd $directory && ls -t | grep ".gz" | head -1)
    info "The last backup file is '${filename}'"
    echo "${directory}/${filename}"
}

#------------------------
# Validation of backup file
#  $1 - filename
#------------------------
validation_backup_file() {
    local restore_file="${1}"
    info "Checking that backup file '${restore_file}' contains needed dumps for restore.."
    if [[ $(tar -tzf $restore_file | grep "ursus"| wc -l) -eq 0 ]]; then
      error "Backup for 'ursus' database is absent in file ${restore_file}"
      exit 1
    fi
    if [[ $(tar -tzf $restore_file | grep "lepus"| wc -l) -eq 0 ]]; then
      error "Backup for 'lepus' database is absent in file ${restore_file}"
      exit 1
    fi
    info "OK, file contains needed database dumps"
}

#------------------------
# Creation a directory with logging
#  $1 - directory name
#------------------------
create_directory() {
    local directory="${1:?directory name is required}"
    info "Creating directory '${directory}'"
    mkdir -p "${directory}" | { read cmd_output; log $cmd_output; }
    if [ ${PIPESTATUS[0]} -ne 0 ]; then
      error "Directory "${directory}" is not created"
      exit 1
    else
      info "ok, directory is created"
    fi
}
