#!/bin/bash
# Скрипт создания бэкапов баз данных NAICE

export OPERATIONS_LOG="${OPERATIONS_LOG:-/tmp/naice_backup.log}"
export BACKUPS_DIR="${BACKUPS_DIR:-/home/worker/backups}"

#------ load libraries from the same directory ----
__dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "${__dir}/backup-env.sh"
. "${__dir}/liblog.sh"
. "${__dir}/libbackup.sh"

set_log_file $OPERATIONS_LOG
switch_on_screen_log

#----------- MAIN LOGIC ----------

#-- Подготовка бэкап файлов и лога -----
BACKUP_ID="$(date +%Y-%m-%d_%H-%M-%S_%3N)"
ursus_back="ursus_${BACKUP_ID}.sql"
lepus_back="lepus_${BACKUP_ID}.sql"
backup_common_arch="naice_${BACKUP_ID}.tar.gz"

set_log_prefix "BACKUP] [${BACKUP_ID}"

#---Проверка параметров окружения ---
info "Validation required env variables for backup"
validate_required_environment_variables "BACKUPS_DIR URSUS_POSTGRES_USERNAME URSUS_POSTGRES_PASSWORD URSUS_POSTGRES_DB LEPUS_POSTGRES_USERNAME LEPUS_POSTGRES_PASSWORD LEPUS_POSTGRES_DB"

#-- Создание директории для хранения, если её нет --
info "Directory for backups from env. variable '\$BACKUPS_DIR:${BACKUPS_DIR}'"
create_directory $BACKUPS_DIR

#-- Создание бэкапов --
backup_database_to_file $URSUS_POSTGRES_USERNAME $URSUS_POSTGRES_PASSWORD $URSUS_POSTGRES_DB "${BACKUPS_DIR}/${ursus_back}"
backup_database_to_file $LEPUS_POSTGRES_USERNAME $LEPUS_POSTGRES_PASSWORD $LEPUS_POSTGRES_DB "${BACKUPS_DIR}/${lepus_back}"

  #-- Сжатие бэкапов в архив  --
info   "Start compressing backups to file ${backup_common_arch}"
if cd $BACKUPS_DIR && tar -czf $backup_common_arch $ursus_back $lepus_back; then
   info "The backup was successfully compressed to '${BACKUPS_DIR}/${backup_common_arch}'"
   rm -rf $ursus_back && rm -rf $lepus_back
else
   error 'Error compressing backup'
   exit 1
fi

#----Удаление старых бэкапов ---
#clean_old_files $BACKUPS_DIR