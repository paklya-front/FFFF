#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

#ENV
. /opt/repmgr/scripts/repmgr-env.sh

# Загрузка вспомогательных библиотек
. /opt/repmgr/scripts/libpostgresql.sh
. /opt/repmgr/scripts/librepmgr.sh

# Установка ENV параметров, определяющих тип узла
eval "$(repmgr_set_role)"

# Initialize PostgreSQL & repmgr
repmgr_initialize