#!/bin/bash
# shellcheck disable=SC1090,SC1091

set -o errexit
set -o nounset
set -o pipefail
# set -o xtrace # Uncomment this line for debugging purposes

. "/opt/repmgr/scripts/events/execs/includes/anotate_event_processing.sh"
. "/opt/repmgr/scripts/events/execs/includes/lock_primary.sh"
. "/opt/repmgr/scripts/events/execs/includes/unlock_standby.sh"
