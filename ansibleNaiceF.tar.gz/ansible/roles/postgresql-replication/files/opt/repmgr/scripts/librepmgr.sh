#!/bin/bash

. /opt/repmgr/scripts/util/liblog.sh
. /opt/repmgr/scripts/util/libnet.sh
. /opt/repmgr/scripts/util/libfs.sh
. /opt/repmgr/scripts/util/libvalidations.sh

########################
# Инициализация repmgr service
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_initialize() {
    info "Primary Node: '${REPMGR_CURRENT_PRIMARY_HOST}:${REPMGR_CURRENT_PRIMARY_PORT}'"
    info "Current node Id: '$REPMGR_NODE_ID' Role: '$REPMGR_ROLE' Switch: '$REPMGR_SWITCH_ROLE'"
    info "Initializing Repmgr..."

    if [[ "$REPMGR_ROLE" == "standby" && "$REPMGR_SWITCH_ROLE" == "yes" ]]; then
        info "Primary change, switch role: yes, start process to standby node"

        info "Stopping PostgreSQL..."
        systemctl stop postgresql@15-main

        POSTGRESQL_MASTER_PORT_NUMBER="$REPMGR_CURRENT_PRIMARY_PORT"
        export POSTGRESQL_MASTER_PORT_NUMBER

        POSTGRESQL_MASTER_HOST="$REPMGR_CURRENT_PRIMARY_HOST"
        export POSTGRESQL_MASTER_HOST

        repmgr_wait_primary_node || exit 1

        info "Rejoining node..."
        ensure_dir_exists "$POSTGRESQL_DATA_DIR"
        repmgr_clone_primary

        info "Start PostgreSQL..."
        systemctl start postgresql@15-main

        repmgr_unregister_standby
        repmgr_register_standby

        info "Check if primary running..."
        repmgr_wait_primary_node
        repmgr_standby_follow
    fi
}

########################
# Назначение роли данной ноде
#
# Глобально (в рамках ноды), кем является данная нода (primary, standby, witness)
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   Series of exports to be used as 'eval' arguments
#########################
repmgr_set_role() {
    local role="standby"
    local primary_node

    local primary_host
    local primary_port
    local switch_role

    readarray -t primary_node < <(repmgr_get_primary_node)
    primary_host=${primary_node[0]}
    primary_port=${primary_node[1]:-$REPMGR_PRIMARY_PORT}
    switch_role=${primary_node[2]}
    if [[ "$REPMGR_NODE_TYPE" = "data" ]]; then
      if [[ -z "$primary_host" ]]; then
        info "There are no nodes with primary role. Assuming the primary role..."
        role="primary"
      else
        info "Node configured as standby"
        role="standby"
      fi
    else
      info "Node configured as witness"
      role="witness"
    fi

    cat <<EOF
export REPMGR_ROLE="$role"
export REPMGR_CURRENT_PRIMARY_HOST="$primary_host"
export REPMGR_CURRENT_PRIMARY_PORT="$primary_port"
export REPMGR_SWITCH_ROLE="$switch_role"
EOF
}

########################
# Получение Primary ноды
#
# Globals:
#   REPMGR_PRIMARY_PORT,REPMGR_PRIMARY_ROLE_LOCK_FILE_NAME,REPMGR_NODE_NETWORK_NAME,REPMGR_PORT_NUMBER,
#   REPMGR_SWITCH_ROLE,REPMGR_PRIMARY_HOST,REPMGR_PRIMARY_PORT,REPMGR_SWITCH_ROLE
# Func exec:
#   liblog.info(), liblog.debug(), repmgr_get_upstream_node
# Arguments:
#   None
# Returns:
#   String[] - (host port)
#########################
repmgr_get_primary_node() {
    local upstream_node
    local upstream_host
    local upstream_port
    local primary_host=""
    local primary_port="$REPMGR_PRIMARY_PORT"
    local switch_role="no"

    readarray -t upstream_node < <(repmgr_get_upstream_node)
    upstream_host=${upstream_node[0]}
    upstream_port=${upstream_node[1]:-$REPMGR_PRIMARY_PORT}
    [[ -n "$upstream_host" ]] && info "Auto-detected primary node: '${upstream_host}:${upstream_port}'"

    if [[ -f "$REPMGR_PRIMARY_ROLE_LOCK_FILE_NAME" ]]; then
        info "This node was acting as a primary before restart!"

        if [[ -z "$upstream_host" ]] || [[ "${upstream_host}:${upstream_port}" = "${REPMGR_NODE_NETWORK_NAME}:${REPMGR_PORT_NUMBER}" ]]; then
            info "Can not find new primary. Starting PostgreSQL normally..."
        else
            info "Current master is '${upstream_host}:${upstream_port}'. Cloning/rewinding it and acting as a standby node..."
            rm -f "$REPMGR_PRIMARY_ROLE_LOCK_FILE_NAME"
            primary_host="$upstream_host"
            primary_port="$upstream_port"
            switch_role="yes"
        fi
    else
        if [[ -z "$upstream_host" ]]; then
            if [[ "${REPMGR_PRIMARY_HOST}:${REPMGR_PRIMARY_PORT}" != "${REPMGR_NODE_NETWORK_NAME}:${REPMGR_PORT_NUMBER}" ]]; then
                primary_host="$REPMGR_PRIMARY_HOST"
                primary_port="$REPMGR_PRIMARY_PORT"
            fi
        else
            if  [[ "${upstream_host}:${upstream_port}" = "${REPMGR_NODE_NETWORK_NAME}:${REPMGR_PORT_NUMBER}" ]];  then
                info "Avoid setting itself as primary. Starting PostgreSQL normally..."
            else
                primary_host="$upstream_host"
                primary_port="$upstream_port"
            fi
        fi
    fi

    [[ -n "$primary_host" ]] && info "Return Primary node: '${primary_host}:${primary_port}'"
    echo "$primary_host"
    echo "$primary_port"
    echo "$switch_role"
}

########################
# Определить какой из узлов является "Primary"
#
# Проверяем каждую ноду из REPMGR_PARTNER_NODES, выполняя запрос в БД к Repmgr БД
#
# Globals:
#   REPMGR_PARTNER_NODES, REPMGR_PRIMARY_PORT, REPMGR_DATABASE, REPMGR_USERNAME, REPMGR_PASSWORD
# Func exec:
#   liblog.info(), liblog.debug(), liblog.warn(), libpostgresql.postgresql_remote_execute(), libnet.parse_uri()
# Arguments:
#   Non
# Returns:
#   String[] - (host port)
#########################
repmgr_get_upstream_node() {
    local primary_conninfo
    local pretending_primary_host=""
    local pretending_primary_port=""
    local host=""
    local port=""
    local suggested_primary_host=""
    local suggested_primary_port=""

    if [[ -n "$REPMGR_PARTNER_NODES" ]]; then
        info "Querying all partner nodes for common upstream node..."
        read -r -a nodes <<<"$(tr ',;' ' ' <<<"${REPMGR_PARTNER_NODES}")"
        for node in "${nodes[@]}"; do
            # intentionally accept inncorect address (without [schema:]// )
            [[ "$node" =~ ^(([^:/?#]+):)?// ]] || node="tcp://${node}"
            host="$(parse_uri "$node" 'host')"
            port="$(parse_uri "$node" 'port')"
            port="${port:-$REPMGR_PRIMARY_PORT}"
            debug "Checking node '$host:$port'..."
            local query="SELECT conninfo FROM repmgr.show_nodes WHERE (upstream_node_name IS NULL OR upstream_node_name = '') AND active=true"
            if ! primary_conninfo="$(echo "$query" | NO_ERRORS=true postgresql_remote_execute "$host" "$port" "$REPMGR_DATABASE" "$REPMGR_USERNAME" "$REPMGR_PASSWORD" "-tA")"; then
                debug "Skipping: failed to get primary from the node '$host:$port'!"
                continue
            elif [[ -z "$primary_conninfo" ]]; then
                debug "Skipping: failed to get information about primary nodes!"
                continue
            elif [[ "$(echo "$primary_conninfo" | wc -l)" -eq 1 ]]; then
                suggested_primary_host="$(echo "$primary_conninfo" | awk -F 'host=' '{print $2}' | awk '{print $1}')"
                suggested_primary_port="$(echo "$primary_conninfo" | awk -F 'port=' '{print $2}' | awk '{print $1}')"
                debug "Pretending primary role node - '${suggested_primary_host}:${suggested_primary_port}'"
                if [[ -n "$pretending_primary_host" ]]; then
                    if [[ "${pretending_primary_host}:${pretending_primary_port}" != "${suggested_primary_host}:${suggested_primary_port}" ]]; then
                        warn "Conflict of pretending primary role nodes (previously: '${pretending_primary_host}:${pretending_primary_port}', now: '${suggested_primary_host}:${suggested_primary_port}')"
                        pretending_primary_host="" && pretending_primary_port="" && break
                    fi
                else
                    debug "Pretending primary set to '${suggested_primary_host}:${suggested_primary_port}'!"
                    pretending_primary_host="$suggested_primary_host"
                    pretending_primary_port="$suggested_primary_port"
                fi
            else
                warn "There were more than one primary when getting primary from node '$host:$port'"
                pretending_primary_host="" && pretending_primary_port="" && break
            fi
        done
    fi

    echo "$pretending_primary_host"
    echo "$pretending_primary_port"
}

########################
# Waits until the primary node responds
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_wait_primary_node() {
    local return_value=1
    local -i timeout=60
    local -i step=10
    local -i max_tries=$((timeout / step))
    local schemata
    info "Waiting for primary node..."
    debug "Wait for schema $REPMGR_DATABASE.repmgr on '${REPMGR_CURRENT_PRIMARY_HOST}:${REPMGR_CURRENT_PRIMARY_PORT}', will try $max_tries times with $step delay seconds (TIMEOUT=$timeout)"
    for ((i = 0; i <= timeout; i += step)); do
        local query="SELECT 1 FROM information_schema.schemata WHERE catalog_name='$REPMGR_DATABASE' AND schema_name='repmgr'"
        if ! schemata="$(echo "$query" | NO_ERRORS=true postgresql_remote_execute "$REPMGR_CURRENT_PRIMARY_HOST" "$REPMGR_CURRENT_PRIMARY_PORT" "$REPMGR_DATABASE" "$REPMGR_USERNAME" "$REPMGR_PASSWORD" "-tA")"; then
            debug "Host '${REPMGR_CURRENT_PRIMARY_HOST}:${REPMGR_CURRENT_PRIMARY_PORT}' is not accessible"
        else
            if [[ $schemata -ne 1 ]]; then
                debug "Schema $REPMGR_DATABASE.repmgr is still not accessible"
            else
                debug "Schema $REPMGR_DATABASE.repmgr exists!"
                return_value=0 && break
            fi
        fi
        sleep "$step"
    done
    return $return_value
}

########################
# Clones data from primary node
# Globals:
#   REPMGR_*
#   POSTGRESQL_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_clone_primary() {
    # Clears WAL directory if existing (pg_basebackup requires the WAL dir to be empty)
    local -r waldir=$(postgresql_get_waldir)
    if [[ -d "$waldir" ]]; then
        info "Deleting existing WAL directory $waldir..."
        rm -rf "$waldir" && ensure_dir_exists "$waldir"
    fi

    info "Cloning data from primary node..."
    local -r flags=("-f" "$REPMGR_CONF_FILE" "-h" "$REPMGR_CURRENT_PRIMARY_HOST" "-p" "$REPMGR_CURRENT_PRIMARY_PORT" "-U" "$REPMGR_USERNAME" "-d" "dbname=$REPMGR_DATABASE host=$REPMGR_CURRENT_PRIMARY_HOST port=$REPMGR_CURRENT_PRIMARY_PORT connect_timeout=$REPMGR_CONNECT_TIMEOUT" "-D" "$POSTGRESQL_DATA_DIR" "standby" "clone" "--fast-checkpoint" "--force")

    if [[ "$REPMGR_USE_PASSFILE" = "true" ]]; then
        debug "Exsists .pass file repmgr execute clone primary..."
        PGPASSFILE="$REPMGR_PASSFILE_PATH" repmgr_execute "${flags[@]}"

    else
        debug "env PGPASSWORD param exists execute clone primary..."
        PGPASSWORD="$REPMGR_PASSWORD" repmgr_execute "${flags[@]}"
    fi
}

########################
# Standby follow.
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_standby_follow() {
    info "Running standby follow..."
    local -r flags=("standby" "follow" "-f" "$REPMGR_CONF_FILE" "-W" "--log-level" "DEBUG" "--verbose")

    if [[ "$REPMGR_USE_PASSFILE" = "true" ]]; then
        PGPASSFILE="$REPMGR_PASSFILE_PATH" repmgr_execute "${flags[@]}"
    else
        PGPASSWORD="$REPMGR_PASSWORD" repmgr_execute "${flags[@]}"
    fi
}

########################
# Get repmgr node id
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   String
#########################
repmgr_get_node_id() {
    local num
    if [[ "$REPMGR_NODE_ID" != "" ]]; then
        echo "$REPMGR_NODE_ID"
    else
        num="${REPMGR_NODE_NAME##*-}"
        if [[ "$num" != "" ]]; then
            num=$((num + REPMGR_NODE_ID_START_SEED))
            echo "$num"
        fi
    fi
}

########################
# Execute repmgr command
# Globals:
#   REPMGR_*
#   POSTGRESQL_DAEMON_USER
# Arguments:
#   $@ - Additional arguments to pass to the repmgr command
# Returns:
#   None
########################
repmgr_execute() {
    local repmgr_cmd=()

    if am_i_root; then
        repmgr_cmd=("run_as_user" "$POSTGRESQL_DAEMON_USER" "${REPMGR_BIN_DIR}/repmgr")
    else
        repmgr_cmd=("${REPMGR_BIN_DIR}/repmgr")
    fi

    debug_execute "${repmgr_cmd[@]}" "$@"
}

########################
# Resgister a node as standby
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_register_standby() {
    info "Registering Standby node..."
    local -r flags=("standby" "register" "-f" "$REPMGR_CONF_FILE" "--force" "--verbose")

    repmgr_execute "${flags[@]}"
}

########################
# Unregister standby node
# Globals:
#   REPMGR_*
# Arguments:
#   None
# Returns:
#   None
#########################
repmgr_unregister_standby() {
    info "Unregistering standby node..."
    local -r flags=("standby" "unregister" "-f" "$REPMGR_CONF_FILE" "--node-id=$(repmgr_get_node_id)")

    # The command below can fail when the node doesn't exist yet
    repmgr_execute "${flags[@]}" || true
}