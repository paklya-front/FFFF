#!/bin/bash

DATE=$(date +"%d-%m-%Y")
DIR_NAME=ansibleNaice-$DATE
mkdir $DIR_NAME

cp -r README.md \
ansible.cfg.template \
hosts.yml \
group_vars \
roles/check-system-requirements \
roles/docker \
roles/keepalived \
roles/monitoring \
roles/postgresql \
roles/postgresql-replication \
roles/https \
roles/check-server-certs-exist \
common-naice-databases.yml \
common-naice-services.yml \
common-postgres-cluster.yml \
reservation-naice-services.yml \
install-monitoring.yml \
restore-default-admin.yml \
docker-postgres-cluster.yml \
$DIR_NAME
